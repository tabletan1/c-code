//
//  main.cpp
//  P4
//
//  Created by Rencheng Tan on 2/9/16.
//  Copyright © 2016 Rencheng Tan. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
