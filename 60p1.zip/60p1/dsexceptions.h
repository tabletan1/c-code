//
//  dsexceptions.h
//  60p1
//
//  Created by Rencheng Tan on 4/7/16.
//  Copyright © 2016 Rencheng Tan. All rights reserved.
//


#ifndef _DSEXCEPTIONS_H_
#define _DSEXCEPTIONS_H_

class Underflow { };
class Overflow  { };
class OutOfMemory { };
class BadIterator { };

#endif
